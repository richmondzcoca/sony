import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-lsi-approval',
    templateUrl: './initial-analysis-lsi-approval.component.html',
    styleUrls: ['./initial-analysis-lsi-approval.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisLsiApprovalComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
