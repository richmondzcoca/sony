import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-main-screen-links',
  templateUrl: './main-screen-links.component.html',
  styleUrls: ['./main-screen-links.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MainScreenLinksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
