import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'app-initial-analysis-is-answer',
    templateUrl: './initial-analysis-is-answer.component.html',
    styleUrls: ['./initial-analysis-is-answer.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisIsAnswerComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
