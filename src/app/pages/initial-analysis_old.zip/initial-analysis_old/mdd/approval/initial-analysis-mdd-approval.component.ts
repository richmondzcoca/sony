import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-mdd-approval',
    templateUrl: './initial-analysis-mdd-approval.component.html',
    styleUrls: ['./initial-analysis-mdd-approval.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisMddApprovalComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
