import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-mdd-request',
    templateUrl: './initial-analysis-mdd-request.component.html',
    styleUrls: ['./initial-analysis-mdd-request.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisMddRequestComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
