import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-laser-request',
    templateUrl: './initial-analysis-laser-request.component.html',
    styleUrls: ['./initial-analysis-laser-request.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisLaserRequestComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
