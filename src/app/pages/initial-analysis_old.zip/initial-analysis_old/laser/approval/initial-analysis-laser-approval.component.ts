import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-laser-approval',
    templateUrl: './initial-analysis-laser-approval.component.html',
    styleUrls: ['./initial-analysis-laser-approval.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisLaserApprovalComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
