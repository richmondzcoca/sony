export const AppConsts = {
    LanguageError: '言語ファイル取得には失敗しまいました。',
};
