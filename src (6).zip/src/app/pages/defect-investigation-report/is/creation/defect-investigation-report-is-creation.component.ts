import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-is-creation',
  templateUrl: './defect-investigation-report-is-creation.component.html',
  styleUrls: ['./defect-investigation-report-is-creation.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportIsCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
