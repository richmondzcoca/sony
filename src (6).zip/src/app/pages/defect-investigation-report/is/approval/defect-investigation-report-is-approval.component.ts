import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-is-approval',
  templateUrl: './defect-investigation-report-is-approval.component.html',
  styleUrls: ['./defect-investigation-report-is-approval.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportIsApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
