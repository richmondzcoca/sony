import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-mdd-creation',
  templateUrl: './defect-investigation-report-mdd-creation.component.html',
  styleUrls: ['./defect-investigation-report-mdd-creation.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportMddCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
