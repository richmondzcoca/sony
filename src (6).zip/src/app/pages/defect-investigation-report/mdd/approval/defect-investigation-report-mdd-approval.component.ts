import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-mdd-approval',
  templateUrl: './defect-investigation-report-mdd-approval.component.html',
  styleUrls: ['./defect-investigation-report-mdd-approval.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportMddApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
