import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-lsi-creation',
  templateUrl: './defect-investigation-report-lsi-creation.component.html',
  styleUrls: ['./defect-investigation-report-lsi-creation.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportLsiCreationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
