import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-defect-investigation-report-lsi-approval',
  templateUrl: './defect-investigation-report-lsi-approval.component.html',
  styleUrls: ['./defect-investigation-report-lsi-approval.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DefectInvestigationReportLsiApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
