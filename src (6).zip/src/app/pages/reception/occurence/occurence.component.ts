import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-occurence',
  templateUrl: './occurence.component.html',
  styleUrls: ['./occurence.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OccurenceComponent implements OnInit {

  constructor() {}

  ngOnInit(): void {

  }

}
