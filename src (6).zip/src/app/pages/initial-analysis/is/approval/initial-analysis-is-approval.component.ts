import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';

@Component({
    selector: 'app-initial-analysis-is-approval',
    templateUrl: './initial-analysis-is-approval.component.html',
    styleUrls: ['./initial-analysis-is-approval.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisIsApprovalComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
