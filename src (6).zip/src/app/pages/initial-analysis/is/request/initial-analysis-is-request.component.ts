import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-is-request',
    templateUrl: './initial-analysis-is-request.component.html',
    styleUrls: ['./initial-analysis-is-request.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisIsRequestComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
