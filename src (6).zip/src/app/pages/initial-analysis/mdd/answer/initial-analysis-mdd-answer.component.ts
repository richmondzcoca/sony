import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-mdd-answer',
    templateUrl: './initial-analysis-mdd-answer.component.html',
    styleUrls: ['./initial-analysis-mdd-answer.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisMddAnswerComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
