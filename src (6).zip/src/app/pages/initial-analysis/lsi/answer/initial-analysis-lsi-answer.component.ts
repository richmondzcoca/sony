import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';


@Component({
    selector: 'app-initial-analysis-lsi-answer',
    templateUrl: './initial-analysis-lsi-answer.component.html',
    styleUrls: ['./initial-analysis-lsi-answer.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisLsiAnswerComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
