import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { InitialAnalysisFinalReportComponent } from '../../common/final-report/final-report.component';

@Component({
    selector: 'app-initial-analysis-laser-answer',
    templateUrl: './initial-analysis-laser-answer.component.html',
    styleUrls: ['./initial-analysis-laser-answer.component.less'],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class InitialAnalysisLaserAnswerComponent implements OnInit {

    constructor() { }
  
    ngOnInit(): void {
    }
  
  }
  
