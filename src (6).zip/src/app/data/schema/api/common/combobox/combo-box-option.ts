export interface ComboBoxOption {
    val: string;
    label: string;
}