import { ComboBoxOption } from "./combo-box-option";

export interface ComboBoxOptionListResponse {
    combobox: ComboBoxOption[];
}