export interface HomeTableInfo {
    title: string;
    subtitle: string;
    section: string;
    user: string;
    email: string;
}
