export interface LoginUser {
    loginId: string;
    role: string[];
}
