export interface UserError {
    resultCode: string;
    resultParamters: any;
}
