export interface User {
    loginId: string;
    username: string;
    globalId: string;
}
