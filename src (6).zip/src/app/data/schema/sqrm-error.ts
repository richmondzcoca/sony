export interface SqrmError {
    resultCode: string;
    resultParamters: any;
}
